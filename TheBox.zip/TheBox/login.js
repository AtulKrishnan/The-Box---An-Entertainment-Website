const signUpButton = document.getElementById('signUp');
		const signInButton = document.getElementById('signIn');
		const container = document.getElementById('container');

		signUpButton.addEventListener('click', () => {
			container.classList.add("right-panel-active");
		});

		signInButton.addEventListener('click', () => {
			container.classList.remove("right-panel-active");
		});
		
		let btn = document.querySelector('#btn');
		var MongoClient = require('mongodb').MongoClient;
		
		function signup()
		{
			//alert("Entered sign up");
			const nam = document.getElementById('name').value;
			if (!nam)
				{
					alert("Please enter the name");
					return;
				}
			const emails = document.getElementById('email').value;
			if (!emails)
				{
					alert("Please enter the email");
					return;
				}
			const passwrd = document.getElementById('password').value;
			if (!passwrd)
				{
					alert("Please enter the password");
					return;
				}
				
			
			MongoClient.connect('mongodb://localhost:27017',{
                    useUnifiedTopology:true
                }, function(err,client){
                    if(err) throw err;
                    const db = client.db('boxdb');
					db.collection('players').findOne(email = email,
                        function(err,docs){
                            alert("User email already present");
							return;
                        })
					db.players.insertOne({name : nam, email : emails, password: passwrd}, function(err, res) {
						if (err) throw err;
						console.log("1 document inserted");
						db.close();
					  });
				});
		}
		btn.addEventListener('click', signup);