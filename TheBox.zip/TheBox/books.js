var express= require('express')
var MongoClient= require('mongodb').MongoClient;
var router= express.Router();

router.get("/",function(req,res){ //GET/student
    MongoClient.connect("mongodb://localhost:27017",{
        useUnifiedTopology:true
    },function(err,client){
        if (err) throw err;
        const db= client.db('newdb')
        db.collection('books').find(req.query).toArray(function(err,objs){
            res.send(objs)
        })
    })
})

router.get("/:id",function(req,res){ //GET/student/PES1234
    MongoClient.connect("mongodb://localhost:27017",{
        useUnifiedTopology:true
    },function(err,client){
        if (err) throw err;
        const db= client.db('newdb')
        db.collection('books').findOne({book_id:parseInt(req.params.id)},function(err,objs){
            res.send(objs)
        })
    })
})

router.post("/",function(req,res){ 
    //POST/student message body{srn="PES67878", name:"abc"}
    MongoClient.connect("mongodb://localhost:27017",{
        useUnifiedTopology:true
    },function(err,client){
        if (err) throw err;
        const db= client.db('newdb')
        db.collection('books').insert(req.body,function(err,objs){
            res.send("Save Succesfull!!!")
        })
    })
})

router.put("/:price",function(req,res){ 
    //PUT/student/PES1234 message body-{srn="",hostel:"yes"}
    MongoClient.connect("mongodb://localhost:27017",{
        useUnifiedTopology:true
    },function(err,client){
        if (err) throw err;
        const db= client.db('newdb')
        db.collection('books').update({book_price:req.params.price}, { $set: req.body },{ new: true, upsert: true, returnOriginal: false },function(err,objs){
            res.send("Update Succesfull!!!")
        })
    })
})

module.exports=router